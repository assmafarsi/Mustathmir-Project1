const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');
const signupForm = document.getElementById('signup-form');
const loginForm = document.getElementById('login-form');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});

document.getElementById('signup-form').addEventListener('submit', function (e) {
  e.preventDefault();
  showMessage('You have successfully registered!', function() {
      window.location.href = 'Virtual Tour.html';
  });
});

document.getElementById('login-form').addEventListener('submit', function (e) {
  e.preventDefault();
  showMessage('You have successfully logged in!', function() {
      window.location.href = 'Virtual Tour.html';
  });
});

function showMessage(message, callback) {
  var messageDiv = document.getElementById('message');
  messageDiv.textContent = message;
  messageDiv.style.display = 'block';
  setTimeout(function () {
      messageDiv.style.display = 'none';
      if (callback) callback();
  }, 3000);
}

document.getElementById('login').addEventListener('click', function () {
  document.getElementById('container').classList.remove('active');
});

document.getElementById('register').addEventListener('click', function () {
  document.getElementById('container').classList.add('active');
});


const firebaseConfig = {
  apiKey: "AIzaSyChcZtEZjqkK1ZFYuw-ULxAPyWoFgxTSxg",
  authDomain: "mustathmer-system.firebaseapp.com",
  databaseURL: "https://mustathmer-system-default-rtdb.firebaseio.com",
  projectId: "mustathmer-system",
  storageBucket: "mustathmer-system.appspot.com",
  messagingSenderId: "502188726306",
  appId: "1:502188726306:web:b5837c7edf585f926d527b"
};
 
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Reference your database
var contactFormDB = firebase.database().ref("contactForm");

document.getElementById("contactForm").addEventListener("submit", submitForm);

function submitForm(e) {
  e.preventDefault();


  var msgContent = getElementVal("msgContent");

  saveMessages(msgContent);

  // Enable alert
  document.querySelector(".alert").style.display = "block";

  // Remove the alert
  setTimeout(() => {
    document.querySelector(".alert").style.display = "none";
  }, 3000);

  // Reset the form
  document.getElementById("contactForm").reset();
}

const saveMessages = (msgContent) => {
  var newContactForm = contactFormDB.push();

  newContactForm.set({
    msgContent: msgContent,
  });
};

const getElementVal = (id) => {
  return document.getElementById(id).value;
};